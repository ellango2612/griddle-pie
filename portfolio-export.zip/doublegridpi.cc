#include <iostream>
#include <cmath>

constexpr bool check_point(double x, double y){
  // see whether or not hypotenus is <= 1
  return std::hypot(x, y)<=1;
}

double gridpi(unsigned npoints) {
    int count = 0;
    // a counter of all points inside the circle
    double x = 0;
    while (x <= 1.0){
    // if x is <= 1, then look at y to see if it's <= 1
      double y = 0;
      while (y <= 1.0){
        if (check_point(x, y)){
        // if hypotenus is <= 1, then increment count
        count++;
        }
        y += 1.0/(npoints - 1.0);
        // check if y is in the circle
      }
      x += 1.0/(npoints-1.0);
      // check if x is in the circle
    }
    return count*4.0/(npoints*npoints);
    // return the pi value using the formula for it
}


constexpr double gridpi2(unsigned npoints) {
    int count = 0;
  // a counter of all points inside the circle
  double x = 0;
  while (x <= 1.0){
  // if x is <= 1, then look at y to see if it's <= 1
    double y = 0;
    while (y <= 1.0){
      if (check_point(x, y)){
      // if hypotenus is <= 1, then increment count
      count++;
      }
      y += 1.0/(npoints - 1.0);
      // check if y is in the circle
    }
    x += 1.0/(npoints-1.0);
    // check if x is in the circle
  }
  return count*4.0/(npoints*npoints);
  // return the pi value using the formula for it
}


int main(){
  // call the function on 10, 100, and 1000
  std::cout <<gridpi2(10000)<< std::endl;
}
